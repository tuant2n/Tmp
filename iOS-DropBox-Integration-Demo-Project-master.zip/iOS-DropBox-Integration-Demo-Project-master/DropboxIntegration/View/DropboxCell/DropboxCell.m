//
//  DropboxCell.m
//  DropboxIntegration
//
//  Created by TheAppGuruz-iOS-101 on 28/04/14.
//  Copyright (c) 2014 TheAppGuruz-iOS-101. All rights reserved.
//

#import "DropboxCell.h"

@implementation DropboxCell

@synthesize lblTitle;
@synthesize btnIcon;

@end
