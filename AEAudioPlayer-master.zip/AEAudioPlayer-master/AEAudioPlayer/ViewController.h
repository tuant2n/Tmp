//
//  ViewController.h
//  AAudioPlayer
//
//  Created by Daniel Jackson on 11/20/14.
//  Copyright (c) 2014 Daniel Jackson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

