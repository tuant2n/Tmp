//
//  AppDelegate.h
//  AEAudioPlayer
//
//  Created by Daniel Jackson on 12/10/14.
//  Copyright (c) 2014 Daniel Jackson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

