//
//  ArtistsViewController.h
//  CloudMusic
//
//  Created by TuanTN on 3/13/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArtistsViewController : UIViewController

@end
