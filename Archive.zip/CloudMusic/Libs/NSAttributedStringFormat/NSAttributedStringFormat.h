@import Foundation;

//! Project version number for NSAttributedStringFormat.
FOUNDATION_EXPORT double NSAttributedStringFormatVersionNumber;

//! Project version string for NSAttributedStringFormat.
FOUNDATION_EXPORT const unsigned char NSAttributedStringFormatVersionString[];

#import "NSAttributedString+CCLFormat.h"
