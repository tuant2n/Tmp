//
//  FilesCell.h
//  CloudMusic
//
//  Created by TuanTN on 4/9/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import "MainCell.h"

@interface FilesCell : MainCell

@end
