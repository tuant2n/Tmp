//
//  SyncDataViewController.h
//  CloudMusic
//
//  Created by TuanTN on 4/18/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SyncDataViewController : UIViewController

@end
