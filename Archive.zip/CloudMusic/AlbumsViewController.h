//
//  AlbumsViewController.h
//  CloudMusic
//
//  Created by TuanTN on 3/6/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlbumsViewController : UIViewController

@property (nonatomic, strong) NSString *iAlbumArtistId, *iGenreId;
@property (nonatomic, strong) NSString *sTitle;

@end
