//
//  SongHeaderTitle.h
//  CloudMusic
//
//  Created by TuanTN8 on 3/24/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderTitle : UITableViewCell

- (void)setTitle:(NSString *)sTitle;
+ (CGFloat)height;

@end
