//
//  AlbumListViewController.h
//  CloudMusic
//
//  Created by TuanTN8 on 3/29/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AlbumObj;

@interface AlbumListViewController : UIViewController

@property (strong, nonatomic) AlbumObj *currentAlbum;

@end
