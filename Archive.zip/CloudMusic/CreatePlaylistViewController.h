//
//  AddToPlaylistViewController.h
//  CloudMusic
//
//  Created by TuanTN8 on 4/15/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreatePlaylistViewController : UIViewController

@property (nonatomic, strong) NSArray *listSong;
@property (nonatomic, strong) id item;

@end
