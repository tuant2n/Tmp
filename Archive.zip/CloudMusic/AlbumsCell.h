//
//  AlbumsCell.h
//  CloudMusic
//
//  Created by TuanTN on 3/26/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainCell.h"

@class AlbumObj;

@interface AlbumsCell : MainCell

- (void)hideExtenal;

@end
