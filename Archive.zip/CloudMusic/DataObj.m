//
//  SearchResultObj.m
//  CloudMusic
//
//  Created by TuanTN on 3/28/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import "DataObj.h"

@implementation DataObj

@end
