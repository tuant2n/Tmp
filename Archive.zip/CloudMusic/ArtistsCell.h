//
//  ArtistsCell.h
//  CloudMusic
//
//  Created by TuanTN8 on 3/28/16.
//  Copyright © 2016 TuanTN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainCell.h"

@class AlbumArtistObj;

@interface ArtistsCell : MainCell

@end
